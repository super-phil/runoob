package com.tarena.web.swfupload.entity;

public class FileBean {
private  String filePath;
private String fileSize;
private String fileName;
private String fileType;
private  boolean  stuats;

public boolean isStuats() {
	return stuats;
}
public void setStuats(boolean stuats) {
	this.stuats = stuats;
}
public String getFilePath() {
	return filePath;
}
public void setFilePath(String filePath) {
	this.filePath = filePath;
}
public String getFileSize() {
	return fileSize;
}
public void setFileSize(String fileSize) {
	this.fileSize = fileSize;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public String getFileType() {
	return fileType;
}
public void setFileType(String fileType) {
	this.fileType = fileType;
}
@Override
public String toString() {
	return "FileBean [filePath=" + filePath + ", fileSize=" + fileSize
			+ ", fileName=" + fileName + ", fileType=" + fileType + ", stuats="
			+ stuats + "]";
}

}

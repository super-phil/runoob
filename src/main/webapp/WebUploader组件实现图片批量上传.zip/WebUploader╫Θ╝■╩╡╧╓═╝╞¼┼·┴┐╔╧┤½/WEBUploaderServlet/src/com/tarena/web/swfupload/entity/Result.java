package com.tarena.web.swfupload.entity;

public class Result {

}

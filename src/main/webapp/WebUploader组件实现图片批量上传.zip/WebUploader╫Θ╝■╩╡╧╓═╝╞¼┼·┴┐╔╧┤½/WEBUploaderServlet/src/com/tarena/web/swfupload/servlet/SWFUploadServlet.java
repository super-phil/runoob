package com.tarena.web.swfupload.servlet;

import java.io.File;
import java.io.IOException;
import java.nio.file.attribute.FileTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.tarena.web.swfupload.entity.FileBean;

@SuppressWarnings("unchecked")
public class SWFUploadServlet extends HttpServlet{
	public  void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			DiskFileItemFactory diskFileItemFactory=new DiskFileItemFactory();
			ServletFileUpload fileUpload=new ServletFileUpload(diskFileItemFactory);
			try {
				List<FileItem> fileItems=fileUpload.parseRequest(request);
				String fileName=null;
					FileBean bean=new FileBean();
				if(!fileItems.isEmpty()||fileItems!=null){
					for(FileItem  fileItem:fileItems){
						if(fileItem.isFormField()){//����Ǳ�����
							continue;
						}else{//�ļ���
							 fileName=fileItem.getName();
							 bean.setFileType(fileItem.getContentType());
							 bean.setFileSize(String.valueOf(fileItem.getSize()/1000));
							 bean.setFileName(fileName);
						}
						String path=getServletContext().getRealPath("/SwfImage");
						String sufx=fileName.substring(fileName.lastIndexOf("."));
						String fileNewName=File.separator+System.currentTimeMillis()+sufx;
						bean.setFilePath("SwfImage"+fileNewName);
						bean.setStuats(true);
						File file=new File(path,fileNewName);
						fileItem.write(file);
						response.getWriter().print(bean);
						//new ObjectMapper().writeValueAsString(bean);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
